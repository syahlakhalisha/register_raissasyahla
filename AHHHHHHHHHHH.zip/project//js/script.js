document.getElementById("registration").addEventListener("submit", function (e) {
  e.preventDefault();

  const nama = document.getElementById("nama").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const number = document.getElementById("number").value;
  const date = document.getElementById("date").value;
  const gender = document.querySelector('input[name="gender"]:checked')?.value || "-";

  const user = { nama, email, password, number, date, gender };

  // Simpan ke localStorage
  localStorage.setItem(email, JSON.stringify(user));

  // Tambahkan ke tabel
  const table = document.getElementById("dataTable").getElementsByTagName("tbody")[0];
  const newRow = table.insertRow();

  newRow.insertCell(0).textContent = nama;
  newRow.insertCell(1).textContent = email;
  newRow.insertCell(2).textContent = password;
  newRow.insertCell(3).textContent = number;
  newRow.insertCell(4).textContent = date;
  newRow.insertCell(5).textContent = gender;

  // Reset form
  document.getElementById("registration").reset();
});